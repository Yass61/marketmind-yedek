INSERT INTO "dinleyici" VALUES('offset','682676032');
