INSERT INTO "dinleyici" VALUES('offset','682676017');
