INSERT INTO "dinleyici" VALUES('offset','682676036');
