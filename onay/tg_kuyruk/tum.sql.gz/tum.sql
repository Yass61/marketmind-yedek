INSERT INTO "tg_kuyruk" VALUES(1,'KARAR','{"karar_id": 1, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 2 \u00b7 video + kapak \u00b7 OZ01</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.7/10 \u00b7 en zay\u0131f format_uyumu (6) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 19.10 14:02 \u00b7 ka\u00e7arsa: yuva bo\u015f ge\u00e7er, i\u00e7erik s\u0131radaki bo\u015f yuvaya kayar\n1 video \u00b7 1 kapak yukar\u0131da\ndikkat: ortalama 8.7/10 \u00b7 en zay\u0131f format_uyumu (6) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: videolar ve kapaklar yukar\u0131da\nReddetmek i\u00e7in: RED OZ01-2 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY OZ01-2"}','2026-10-19T14:02:00+03:00','OZ01-2','ONAY 2 · video + kapak','2026-10-16T21:24:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(2,'BILGI','⚠️ Kuyrukta 3 hazır senaryo kaldı (B09, OZ01, S02). Hedef: 4. ⛔ Zamanlayıcı senaryo yazmaz — insan yazar.',NULL,NULL,NULL,'2026-10-19T14:05:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(3,'KARAR','{"karar_id": 2, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 1 \u00b7 senaryo \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 23.10 10:00 \u00b7 ka\u00e7arsa: \u00fcretim kayar, yuva riske girer\n25 sahne\nKANCA: Ekranda momentumu y\u00fckselen bir hisse g\u00f6rd\u00fcn.\ndikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: B09_FINAL.md (ekte)\nReddetmek i\u00e7in: RED B09-1 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-1"}','2026-10-23T10:00:00+03:00','B09-1','ONAY 1 · senaryo','2026-10-21T10:08:35+03:00','iptal',NULL);
INSERT INTO "tg_kuyruk" VALUES(4,'KARAR','{"karar_id": 3, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 1 \u00b7 senaryo \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 23.10 10:00 \u00b7 ka\u00e7arsa: \u00fcretim kayar, yuva riske girer\n23 sahne\nKANCA: Ekranda momentumu y\u00fckselen bir hisse g\u00f6rd\u00fcn.\ndikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: B09_FINAL.md (ekte)\nReddetmek i\u00e7in: RED B09-1 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-1"}','2026-10-23T10:00:00+03:00','B09-1','ONAY 1 · senaryo','2026-10-21T16:09:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(5,'KARAR','{"karar_id": 4, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 1 \u00b7 senaryo \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 23.10 10:00 \u00b7 ka\u00e7arsa: \u00fcretim kayar, yuva riske girer\n26 sahne\nKANCA: Ekranda momentumu y\u00fckselen bir hisse g\u00f6rd\u00fcn.\ndikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: B09_FINAL.md (ekte)\nReddetmek i\u00e7in: RED B09-1 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-1"}','2026-10-23T10:00:00+03:00','B09-1','ONAY 1 · senaryo','2026-10-22T14:28:07+03:00','iptal',NULL);
INSERT INTO "tg_kuyruk" VALUES(6,'KARAR','{"karar_id": 5, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 1 \u00b7 senaryo \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 23.10 10:00 \u00b7 ka\u00e7arsa: \u00fcretim kayar, yuva riske girer\n26 sahne\nKANCA: Ekranda momentumu y\u00fckselen bir hisse g\u00f6rd\u00fcn.\ndikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: B09_FINAL.md (ekte)\nReddetmek i\u00e7in: RED B09-1 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-1"}','2026-10-23T10:00:00+03:00','B09-1','ONAY 1 · senaryo','2026-10-22T15:09:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(7,'KARAR','{"karar_id": 7, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 2 \u00b7 video + kapak \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 \ud83d\udd34 D\u0130KKAT D\u00dc\u015e\u00dcK: ortalama 7.5/10 \u00b7 en zay\u0131f format_uyumu (5) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 26.10 14:02 \u00b7 ka\u00e7arsa: yuva bo\u015f ge\u00e7er, i\u00e7erik s\u0131radaki bo\u015f yuvaya kayar\n1 video \u00b7 1 kapak yukar\u0131da\n\ud83d\udd34 D\u0130KKAT D\u00dc\u015e\u00dcK: ortalama 7.5/10 \u00b7 en zay\u0131f format_uyumu (5) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: videolar ve kapaklar yukar\u0131da\nReddetmek i\u00e7in: RED B09-2 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-2"}','2026-10-26T14:02:00+03:00','B09-2','ONAY 2 · video + kapak','2026-10-24T10:12:46+03:00','iptal',NULL);
INSERT INTO "tg_kuyruk" VALUES(8,'BILGI','ℹ️ BİLGİ · Haftalık üretim: bugünün yuvası BOŞ geçti — kapısı temiz senaryo yok (2026-10-26; ileri tarihe atanmışlar seçilmez). Yeni senaryo yazılmalı (ya da bekleyenlerin künye/ANLAM eksikleri tamamlanmalı). Tutulan: B09, GN01, S01, S02, S03.',NULL,NULL,NULL,'2026-10-26T14:03:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(9,'BILGI','Bugün bir şey istenmiyor.
Görev akışının ilk denemesi yapıldı.
Kullanım ölçüsü geliyor.',NULL,NULL,NULL,'2026-10-31T21:40:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(10,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T21:40:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(11,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T21:50:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(12,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T22:01:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(13,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T22:20:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(14,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T22:30:40+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(15,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T22:50:50+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(16,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T23:00:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(17,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T00:30:47+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(18,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T00:40:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(19,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T00:50:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(20,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:00:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(21,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:11:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(22,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:20:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(23,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:31:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(24,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:41:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(25,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:51:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(26,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:01:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(27,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:11:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(28,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:21:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(29,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:31:22+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(30,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:41:31+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(31,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:51:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(32,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:01:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(33,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:11:40+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(34,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:21:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(35,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:31:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(36,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:41:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(37,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:51:50+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(38,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:01:50+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(39,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:11:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(40,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:22:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(41,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:31:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(42,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:41:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(43,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:52:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(44,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T05:02:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(45,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T05:12:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(46,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T05:22:06+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(47,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T05:32:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(48,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T05:42:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(49,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T05:52:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(50,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T06:02:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(51,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T06:12:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(52,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T06:22:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(53,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T06:32:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(54,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T06:42:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(55,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T06:52:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(56,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T07:02:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(57,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T07:12:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(58,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T07:22:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(59,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T07:32:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(60,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T07:42:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(61,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T07:52:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(62,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T08:02:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(63,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T08:12:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(64,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T08:22:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(65,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T08:32:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(66,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T08:43:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(67,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T08:53:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(68,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T09:03:31+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(69,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T09:13:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(70,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T09:23:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(71,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T09:33:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(72,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T09:43:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(73,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T09:53:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(74,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T10:03:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(75,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T10:13:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(76,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T10:23:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(77,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T10:33:34+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(78,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T10:43:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(79,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T10:53:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(80,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T11:03:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(81,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T11:13:40+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(82,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T11:23:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(83,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T11:33:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(84,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T11:43:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(85,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T11:53:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(86,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T12:03:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(87,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T12:13:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(88,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T12:24:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(89,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T12:34:33+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(90,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T12:44:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(91,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T12:54:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(92,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T13:04:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(93,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T13:14:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(94,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T13:24:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(95,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T13:34:22+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(96,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T13:44:28+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(97,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T13:54:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(98,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T14:04:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(99,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T14:14:28+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(100,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T14:24:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(101,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T14:34:33+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(102,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T14:44:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(103,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T14:55:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(104,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T15:04:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(105,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T15:14:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(106,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T15:24:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(107,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T15:34:50+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(108,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T15:44:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(109,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T15:54:53+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(110,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T16:04:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(111,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T16:14:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(112,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T16:25:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(113,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T16:35:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(114,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T16:45:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(115,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T16:55:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(116,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T17:05:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(117,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T17:15:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(118,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T17:25:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(119,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T17:35:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(120,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T17:45:16+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(121,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T17:55:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(122,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T18:05:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(123,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T18:15:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(124,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T18:25:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(125,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T18:35:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(126,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T18:45:33+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(127,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T18:55:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(128,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T19:05:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(129,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T19:15:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(130,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T19:25:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(131,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T19:35:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(132,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T19:45:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(133,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T19:55:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(134,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T20:05:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(135,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T20:16:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(136,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T20:25:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(137,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T20:35:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(138,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T20:45:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(139,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T20:55:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(140,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T21:06:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(141,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T21:16:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(142,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T21:26:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(143,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T21:36:06+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(144,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T21:46:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(145,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T21:56:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(146,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T22:06:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(147,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T22:16:19+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(148,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T22:26:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(149,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T22:36:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(150,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T22:46:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(151,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T22:56:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(152,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T23:06:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(153,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T23:16:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(154,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T23:26:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(155,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T23:36:28+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(156,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T23:46:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(157,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T23:56:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(158,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T00:06:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(159,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T00:16:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(160,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T00:26:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(161,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T00:36:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(162,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T00:46:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(163,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T00:57:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(164,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T01:06:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(165,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T01:16:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(166,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T01:26:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(167,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T01:37:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(168,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T01:47:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(169,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T01:57:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(170,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T02:07:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(171,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T02:17:08+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(172,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T02:27:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(173,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T02:37:16+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(174,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T02:47:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(175,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T02:57:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(176,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T03:07:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(177,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T03:17:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(178,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T03:27:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(179,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T03:37:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(180,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T03:47:29+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(181,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T03:57:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(182,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T04:07:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(183,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T04:17:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(184,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T04:27:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(185,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T04:37:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(186,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T04:47:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(187,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T04:57:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(188,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T05:07:53+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(189,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T05:18:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(190,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T05:27:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(191,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T05:38:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(192,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T05:48:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(193,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T05:58:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(194,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T06:08:22+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(195,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T06:18:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(196,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T06:28:40+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(197,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T06:38:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(198,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T06:48:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(199,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T06:58:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(200,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T07:08:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(201,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T07:18:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(202,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T07:28:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(203,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T07:38:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(204,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T07:48:47+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(205,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T07:58:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(206,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T08:09:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(207,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T08:18:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(208,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T08:28:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(209,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T08:39:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(210,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T08:49:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(211,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T08:59:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(212,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T09:09:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(213,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T09:19:08+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(214,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T09:29:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(215,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T09:39:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(216,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T09:49:18+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(217,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T09:59:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(218,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T10:09:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(219,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T10:19:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(220,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T10:29:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(221,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T10:39:29+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(222,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T10:49:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(223,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T10:59:34+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(224,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T11:09:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(225,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T11:19:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(226,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T11:29:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(227,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T11:39:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(228,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T11:49:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(229,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T11:59:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(230,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T12:09:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(231,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T12:19:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(232,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T12:30:29+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(233,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T12:39:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(234,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T12:49:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(235,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T12:59:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(236,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T13:10:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(237,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T13:20:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(238,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T13:30:08+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(239,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T13:40:22+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(240,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T13:50:18+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(241,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T14:00:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(242,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T14:10:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(243,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T14:20:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(244,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T14:30:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(245,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T14:40:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(246,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T14:50:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(247,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T15:00:34+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(248,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T15:10:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(249,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T15:20:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(250,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T15:30:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(251,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T15:40:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(252,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T15:50:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(253,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T16:00:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(254,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T16:10:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(255,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T16:21:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(256,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T16:30:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(257,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T16:40:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(258,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T16:50:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(259,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T17:00:53+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(260,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T17:10:53+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(261,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T17:20:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(262,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T17:31:16+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(263,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T17:40:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(264,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T17:51:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(265,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T18:01:08+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(266,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T18:11:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(267,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T18:21:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(268,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T18:31:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(269,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T18:41:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(270,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T18:51:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(271,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T19:01:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(272,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T19:11:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(273,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T19:21:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(274,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T19:31:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(275,'BILGI','HAZIRLIK · Senden istenen: kaçmaması gereken işlere bak · günlük tarama hattı (19:00) için bir sonraki çalışma zamanı yok',NULL,NULL,NULL,'2026-11-02T19:40:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(276,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T19:41:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(277,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T19:51:31+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(278,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T20:01:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(279,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T20:11:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(280,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T20:21:28+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(281,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T20:31:44+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(282,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T20:41:37+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(283,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T20:51:35+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(284,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T21:01:56+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(285,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T21:11:40+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(286,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T21:22:13+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(287,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T21:32:05+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(288,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T21:41:53+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(289,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T21:51:44+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(290,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T22:02:07+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(291,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T22:11:57+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(292,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T22:21:59+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(293,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T22:31:57+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(294,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T22:42:03+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(295,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T22:52:09+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(296,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T23:02:10+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(297,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T23:12:59+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(298,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T23:22:11+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(299,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T23:32:13+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(300,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T23:42:25+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(301,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T23:52:33+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(302,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T00:02:26+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(303,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T00:12:34+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(304,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T00:22:30+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(305,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T00:32:38+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(306,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T00:42:38+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(307,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T00:52:37+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(308,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T01:02:39+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(309,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T01:12:42+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(310,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T01:22:48+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(311,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T01:32:42+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(312,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T01:42:45+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(313,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T01:52:57+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(314,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T02:02:58+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(315,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T02:12:54+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(316,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T02:22:54+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(317,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T02:33:04+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(318,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T02:43:06+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(319,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T02:53:00+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(320,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T03:03:05+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(321,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T03:13:11+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(322,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T03:23:13+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(323,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T03:33:15+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(324,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T03:43:16+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(325,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T03:53:25+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(326,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T04:03:43+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(327,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T04:13:26+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(328,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T04:23:30+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(329,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T04:33:32+03:00','bekliyor',NULL);
