INSERT INTO "tg_kuyruk" VALUES(1,'KARAR','{"karar_id": 1, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 2 \u00b7 video + kapak \u00b7 OZ01</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.7/10 \u00b7 en zay\u0131f format_uyumu (6) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 19.10 14:02 \u00b7 ka\u00e7arsa: yuva bo\u015f ge\u00e7er, i\u00e7erik s\u0131radaki bo\u015f yuvaya kayar\n1 video \u00b7 1 kapak yukar\u0131da\ndikkat: ortalama 8.7/10 \u00b7 en zay\u0131f format_uyumu (6) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: videolar ve kapaklar yukar\u0131da\nReddetmek i\u00e7in: RED OZ01-2 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY OZ01-2"}','2026-10-19T14:02:00+03:00','OZ01-2','ONAY 2 · video + kapak','2026-10-16T21:24:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(2,'BILGI','⚠️ Kuyrukta 3 hazır senaryo kaldı (B09, OZ01, S02). Hedef: 4. ⛔ Zamanlayıcı senaryo yazmaz — insan yazar.',NULL,NULL,NULL,'2026-10-19T14:05:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(3,'KARAR','{"karar_id": 2, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 1 \u00b7 senaryo \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 23.10 10:00 \u00b7 ka\u00e7arsa: \u00fcretim kayar, yuva riske girer\n25 sahne\nKANCA: Ekranda momentumu y\u00fckselen bir hisse g\u00f6rd\u00fcn.\ndikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: B09_FINAL.md (ekte)\nReddetmek i\u00e7in: RED B09-1 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-1"}','2026-10-23T10:00:00+03:00','B09-1','ONAY 1 · senaryo','2026-10-21T10:08:35+03:00','iptal',NULL);
INSERT INTO "tg_kuyruk" VALUES(4,'KARAR','{"karar_id": 3, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 1 \u00b7 senaryo \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 23.10 10:00 \u00b7 ka\u00e7arsa: \u00fcretim kayar, yuva riske girer\n23 sahne\nKANCA: Ekranda momentumu y\u00fckselen bir hisse g\u00f6rd\u00fcn.\ndikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: B09_FINAL.md (ekte)\nReddetmek i\u00e7in: RED B09-1 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-1"}','2026-10-23T10:00:00+03:00','B09-1','ONAY 1 · senaryo','2026-10-21T16:09:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(5,'KARAR','{"karar_id": 4, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 1 \u00b7 senaryo \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 23.10 10:00 \u00b7 ka\u00e7arsa: \u00fcretim kayar, yuva riske girer\n26 sahne\nKANCA: Ekranda momentumu y\u00fckselen bir hisse g\u00f6rd\u00fcn.\ndikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: B09_FINAL.md (ekte)\nReddetmek i\u00e7in: RED B09-1 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-1"}','2026-10-23T10:00:00+03:00','B09-1','ONAY 1 · senaryo','2026-10-22T14:28:07+03:00','iptal',NULL);
INSERT INTO "tg_kuyruk" VALUES(6,'KARAR','{"karar_id": 5, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 1 \u00b7 senaryo \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 23.10 10:00 \u00b7 ka\u00e7arsa: \u00fcretim kayar, yuva riske girer\n26 sahne\nKANCA: Ekranda momentumu y\u00fckselen bir hisse g\u00f6rd\u00fcn.\ndikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: B09_FINAL.md (ekte)\nReddetmek i\u00e7in: RED B09-1 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-1"}','2026-10-23T10:00:00+03:00','B09-1','ONAY 1 · senaryo','2026-10-22T15:09:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(7,'KARAR','{"karar_id": 7, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 2 \u00b7 video + kapak \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 \ud83d\udd34 D\u0130KKAT D\u00dc\u015e\u00dcK: ortalama 7.5/10 \u00b7 en zay\u0131f format_uyumu (5) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 26.10 14:02 \u00b7 ka\u00e7arsa: yuva bo\u015f ge\u00e7er, i\u00e7erik s\u0131radaki bo\u015f yuvaya kayar\n1 video \u00b7 1 kapak yukar\u0131da\n\ud83d\udd34 D\u0130KKAT D\u00dc\u015e\u00dcK: ortalama 7.5/10 \u00b7 en zay\u0131f format_uyumu (5) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: videolar ve kapaklar yukar\u0131da\nReddetmek i\u00e7in: RED B09-2 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-2"}','2026-10-26T14:02:00+03:00','B09-2','ONAY 2 · video + kapak','2026-10-24T10:12:46+03:00','iptal',NULL);
INSERT INTO "tg_kuyruk" VALUES(8,'BILGI','ℹ️ BİLGİ · Haftalık üretim: bugünün yuvası BOŞ geçti — kapısı temiz senaryo yok (2026-10-26; ileri tarihe atanmışlar seçilmez). Yeni senaryo yazılmalı (ya da bekleyenlerin künye/ANLAM eksikleri tamamlanmalı). Tutulan: B09, GN01, S01, S02, S03.',NULL,NULL,NULL,'2026-10-26T14:03:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(9,'BILGI','Bugün bir şey istenmiyor.
Görev akışının ilk denemesi yapıldı.
Kullanım ölçüsü geliyor.',NULL,NULL,NULL,'2026-10-31T21:40:12+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(10,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T21:40:32+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(11,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T21:50:38+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(12,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T22:01:37+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(13,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T22:20:36+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(14,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T22:30:40+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(15,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T22:50:50+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(16,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T23:00:45+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(17,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T00:30:47+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(18,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T00:40:58+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(19,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T00:50:48+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(20,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:00:56+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(21,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:11:14+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(22,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:20:57+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(23,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:31:02+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(24,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:41:24+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(25,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:51:12+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(26,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:01:11+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(27,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:11:15+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(28,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:21:44+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(29,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:31:22+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(30,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:41:31+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(31,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:51:30+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(32,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:01:37+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(33,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:11:40+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(34,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:21:46+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(35,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:31:39+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(36,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:41:48+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(37,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:51:50+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(38,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:01:50+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(39,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:11:48+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(40,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:22:09+03:00','bekliyor',NULL);
INSERT INTO "tg_kuyruk" VALUES(41,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:31:59+03:00','bekliyor',NULL);
