INSERT INTO "tg_kuyruk" VALUES(1,'KARAR','{"karar_id": 1, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 2 \u00b7 video + kapak \u00b7 OZ01</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.7/10 \u00b7 en zay\u0131f format_uyumu (6) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 19.10 14:02 \u00b7 ka\u00e7arsa: yuva bo\u015f ge\u00e7er, i\u00e7erik s\u0131radaki bo\u015f yuvaya kayar\n1 video \u00b7 1 kapak yukar\u0131da\ndikkat: ortalama 8.7/10 \u00b7 en zay\u0131f format_uyumu (6) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: videolar ve kapaklar yukar\u0131da\nReddetmek i\u00e7in: RED OZ01-2 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY OZ01-2"}','2026-10-19T14:02:00+03:00','OZ01-2','ONAY 2 · video + kapak','2026-10-16T21:24:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(2,'BILGI','⚠️ Kuyrukta 3 hazır senaryo kaldı (B09, OZ01, S02). Hedef: 4. ⛔ Zamanlayıcı senaryo yazmaz — insan yazar.',NULL,NULL,NULL,'2026-10-19T14:05:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(3,'KARAR','{"karar_id": 2, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 1 \u00b7 senaryo \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 23.10 10:00 \u00b7 ka\u00e7arsa: \u00fcretim kayar, yuva riske girer\n25 sahne\nKANCA: Ekranda momentumu y\u00fckselen bir hisse g\u00f6rd\u00fcn.\ndikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: B09_FINAL.md (ekte)\nReddetmek i\u00e7in: RED B09-1 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-1"}','2026-10-23T10:00:00+03:00','B09-1','ONAY 1 · senaryo','2026-10-21T10:08:35+03:00','iptal',NULL);
INSERT INTO "tg_kuyruk" VALUES(4,'KARAR','{"karar_id": 3, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 1 \u00b7 senaryo \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 23.10 10:00 \u00b7 ka\u00e7arsa: \u00fcretim kayar, yuva riske girer\n23 sahne\nKANCA: Ekranda momentumu y\u00fckselen bir hisse g\u00f6rd\u00fcn.\ndikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: B09_FINAL.md (ekte)\nReddetmek i\u00e7in: RED B09-1 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-1"}','2026-10-23T10:00:00+03:00','B09-1','ONAY 1 · senaryo','2026-10-21T16:09:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(5,'KARAR','{"karar_id": 4, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 1 \u00b7 senaryo \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 23.10 10:00 \u00b7 ka\u00e7arsa: \u00fcretim kayar, yuva riske girer\n26 sahne\nKANCA: Ekranda momentumu y\u00fckselen bir hisse g\u00f6rd\u00fcn.\ndikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: B09_FINAL.md (ekte)\nReddetmek i\u00e7in: RED B09-1 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-1"}','2026-10-23T10:00:00+03:00','B09-1','ONAY 1 · senaryo','2026-10-22T14:28:07+03:00','iptal',NULL);
INSERT INTO "tg_kuyruk" VALUES(6,'KARAR','{"karar_id": 5, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 1 \u00b7 senaryo \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 dikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 23.10 10:00 \u00b7 ka\u00e7arsa: \u00fcretim kayar, yuva riske girer\n26 sahne\nKANCA: Ekranda momentumu y\u00fckselen bir hisse g\u00f6rd\u00fcn.\ndikkat: ortalama 8.5/10 \u00b7 en zay\u0131f netlik (7) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: B09_FINAL.md (ekte)\nReddetmek i\u00e7in: RED B09-1 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-1"}','2026-10-23T10:00:00+03:00','B09-1','ONAY 1 · senaryo','2026-10-22T15:09:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(7,'KARAR','{"karar_id": 7, "metin": "\ud83d\udd34 <b>KARARIN GEREKL\u0130 \u00b7 ONAY 2 \u00b7 video + kapak \u00b7 B09</b>\n<blockquote><b>\u00d6neri: BAK \u2014 \ud83d\udd34 D\u0130KKAT D\u00dc\u015e\u00dcK: ortalama 7.5/10 \u00b7 en zay\u0131f format_uyumu (5) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)</b> \u2014 \u00f6neriyi i\u015fi yapan yazd\u0131</blockquote>\n<b>Son saat:</b> 26.10 14:02 \u00b7 ka\u00e7arsa: yuva bo\u015f ge\u00e7er, i\u00e7erik s\u0131radaki bo\u015f yuvaya kayar\n1 video \u00b7 1 kapak yukar\u0131da\n\ud83d\udd34 D\u0130KKAT D\u00dc\u015e\u00dcK: ortalama 7.5/10 \u00b7 en zay\u0131f format_uyumu (5) \u2014 \u26a0\ufe0f yorum, \u00f6l\u00e7\u00fcm de\u011fil (bloklamaz)\nAyr\u0131nt\u0131: videolar ve kapaklar yukar\u0131da\nReddetmek i\u00e7in: RED B09-2 &lt;sebep&gt;\nOnaylamak i\u00e7in: ONAY B09-2"}','2026-10-26T14:02:00+03:00','B09-2','ONAY 2 · video + kapak','2026-10-24T10:12:46+03:00','iptal',NULL);
INSERT INTO "tg_kuyruk" VALUES(8,'BILGI','ℹ️ BİLGİ · Haftalık üretim: bugünün yuvası BOŞ geçti — kapısı temiz senaryo yok (2026-10-26; ileri tarihe atanmışlar seçilmez). Yeni senaryo yazılmalı (ya da bekleyenlerin künye/ANLAM eksikleri tamamlanmalı). Tutulan: B09, GN01, S01, S02, S03.',NULL,NULL,NULL,'2026-10-26T14:03:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(9,'BILGI','Bugün bir şey istenmiyor.
Görev akışının ilk denemesi yapıldı.
Kullanım ölçüsü geliyor.',NULL,NULL,NULL,'2026-10-31T21:40:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(10,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T21:40:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(11,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T21:50:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(12,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T22:01:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(13,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T22:20:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(14,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T22:30:40+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(15,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T22:50:50+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(16,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-10-31T23:00:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(17,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T00:30:47+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(18,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T00:40:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(19,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T00:50:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(20,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:00:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(21,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:11:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(22,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:20:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(23,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:31:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(24,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:41:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(25,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T01:51:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(26,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:01:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(27,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:11:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(28,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:21:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(29,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:31:22+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(30,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:41:31+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(31,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T02:51:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(32,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:01:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(33,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:11:40+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(34,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:21:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(35,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:31:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(36,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:41:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(37,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T03:51:50+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(38,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:01:50+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(39,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:11:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(40,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:22:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(41,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:31:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(42,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:41:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(43,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T04:52:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(44,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T05:02:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(45,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T05:12:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(46,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T05:22:06+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(47,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T05:32:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(48,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T05:42:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(49,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T05:52:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(50,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T06:02:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(51,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T06:12:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(52,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T06:22:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(53,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T06:32:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(54,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T06:42:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(55,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T06:52:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(56,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T07:02:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(57,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T07:12:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(58,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T07:22:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(59,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T07:32:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(60,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T07:42:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(61,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T07:52:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(62,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T08:02:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(63,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T08:12:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(64,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T08:22:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(65,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T08:32:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(66,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T08:43:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(67,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T08:53:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(68,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T09:03:31+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(69,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T09:13:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(70,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T09:23:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(71,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T09:33:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(72,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T09:43:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(73,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T09:53:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(74,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T10:03:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(75,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T10:13:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(76,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T10:23:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(77,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T10:33:34+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(78,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T10:43:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(79,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T10:53:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(80,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T11:03:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(81,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T11:13:40+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(82,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T11:23:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(83,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T11:33:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(84,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T11:43:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(85,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T11:53:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(86,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T12:03:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(87,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T12:13:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(88,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T12:24:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(89,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T12:34:33+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(90,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T12:44:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(91,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T12:54:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(92,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T13:04:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(93,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T13:14:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(94,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T13:24:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(95,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T13:34:22+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(96,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T13:44:28+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(97,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T13:54:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(98,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T14:04:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(99,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T14:14:28+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(100,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T14:24:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(101,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T14:34:33+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(102,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T14:44:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(103,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T14:55:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(104,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T15:04:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(105,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T15:14:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(106,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T15:24:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(107,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T15:34:50+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(108,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T15:44:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(109,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T15:54:53+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(110,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T16:04:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(111,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T16:14:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(112,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T16:25:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(113,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T16:35:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(114,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T16:45:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(115,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T16:55:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(116,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T17:05:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(117,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T17:15:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(118,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T17:25:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(119,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T17:35:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(120,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T17:45:16+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(121,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T17:55:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(122,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T18:05:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(123,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T18:15:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(124,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T18:25:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(125,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T18:35:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(126,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T18:45:33+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(127,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T18:55:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(128,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T19:05:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(129,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T19:15:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(130,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T19:25:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(131,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T19:35:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(132,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T19:45:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(133,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T19:55:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(134,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T20:05:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(135,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T20:16:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(136,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T20:25:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(137,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T20:35:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(138,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T20:45:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(139,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T20:55:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(140,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T21:06:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(141,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T21:16:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(142,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T21:26:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(143,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T21:36:06+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(144,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T21:46:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(145,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T21:56:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(146,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T22:06:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(147,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T22:16:19+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(148,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T22:26:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(149,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T22:36:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(150,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T22:46:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(151,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T22:56:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(152,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T23:06:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(153,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T23:16:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(154,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T23:26:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(155,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T23:36:28+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(156,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T23:46:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(157,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-01T23:56:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(158,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T00:06:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(159,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T00:16:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(160,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T00:26:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(161,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T00:36:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(162,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T00:46:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(163,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T00:57:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(164,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T01:06:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(165,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T01:16:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(166,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T01:26:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(167,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T01:37:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(168,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T01:47:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(169,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T01:57:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(170,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T02:07:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(171,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T02:17:08+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(172,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T02:27:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(173,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T02:37:16+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(174,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T02:47:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(175,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T02:57:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(176,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T03:07:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(177,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T03:17:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(178,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T03:27:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(179,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T03:37:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(180,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T03:47:29+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(181,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T03:57:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(182,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T04:07:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(183,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T04:17:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(184,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T04:27:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(185,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T04:37:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(186,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T04:47:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(187,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T04:57:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(188,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T05:07:53+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(189,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T05:18:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(190,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T05:27:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(191,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T05:38:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(192,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T05:48:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(193,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T05:58:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(194,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T06:08:22+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(195,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T06:18:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(196,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T06:28:40+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(197,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T06:38:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(198,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T06:48:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(199,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T06:58:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(200,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T07:08:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(201,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T07:18:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(202,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T07:28:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(203,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T07:38:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(204,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T07:48:47+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(205,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T07:58:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(206,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T08:09:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(207,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T08:18:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(208,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T08:28:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(209,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T08:39:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(210,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T08:49:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(211,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T08:59:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(212,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T09:09:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(213,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T09:19:08+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(214,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T09:29:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(215,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T09:39:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(216,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T09:49:18+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(217,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T09:59:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(218,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T10:09:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(219,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T10:19:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(220,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T10:29:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(221,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T10:39:29+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(222,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T10:49:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(223,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T10:59:34+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(224,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T11:09:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(225,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T11:19:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(226,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T11:29:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(227,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T11:39:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(228,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T11:49:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(229,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T11:59:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(230,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T12:09:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(231,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T12:19:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(232,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T12:30:29+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(233,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T12:39:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(234,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T12:49:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(235,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T12:59:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(236,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T13:10:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(237,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T13:20:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(238,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T13:30:08+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(239,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T13:40:22+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(240,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T13:50:18+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(241,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T14:00:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(242,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T14:10:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(243,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T14:20:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(244,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T14:30:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(245,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T14:40:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(246,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T14:50:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(247,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T15:00:34+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(248,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T15:10:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(249,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T15:20:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(250,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T15:30:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(251,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T15:40:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(252,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T15:50:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(253,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T16:00:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(254,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T16:10:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(255,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T16:21:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(256,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T16:30:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(257,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T16:40:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(258,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T16:50:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(259,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T17:00:53+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(260,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T17:10:53+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(261,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T17:20:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(262,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T17:31:16+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(263,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T17:40:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(264,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T17:51:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(265,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T18:01:08+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(266,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T18:11:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(267,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T18:21:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(268,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T18:31:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(269,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T18:41:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(270,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T18:51:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(271,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T19:01:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(272,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T19:11:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(273,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T19:21:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(274,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T19:31:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(275,'BILGI','HAZIRLIK · Senden istenen: kaçmaması gereken işlere bak · günlük tarama hattı (19:00) için bir sonraki çalışma zamanı yok',NULL,NULL,NULL,'2026-11-02T19:40:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(276,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T19:41:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(277,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T19:51:31+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(278,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T20:01:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(279,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T20:11:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(280,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T20:21:28+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(281,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T20:31:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(282,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T20:41:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(283,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T20:51:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(284,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T21:01:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(285,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T21:11:40+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(286,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T21:22:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(287,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T21:32:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(288,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T21:41:53+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(289,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T21:51:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(290,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T22:02:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(291,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T22:11:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(292,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T22:21:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(293,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T22:31:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(294,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T22:42:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(295,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T22:52:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(296,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T23:02:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(297,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T23:12:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(298,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T23:22:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(299,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T23:32:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(300,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T23:42:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(301,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-02T23:52:33+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(302,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T00:02:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(303,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T00:12:34+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(304,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T00:22:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(305,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T00:32:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(306,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T00:42:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(307,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T00:52:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(308,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T01:02:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(309,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T01:12:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(310,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T01:22:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(311,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T01:32:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(312,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T01:42:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(313,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T01:52:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(314,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T02:02:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(315,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T02:12:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(316,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T02:22:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(317,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T02:33:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(318,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T02:43:06+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(319,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T02:53:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(320,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T03:03:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(321,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T03:13:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(322,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T03:23:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(323,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T03:33:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(324,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T03:43:16+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(325,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T03:53:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(326,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T04:03:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(327,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T04:13:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(328,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T04:23:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(329,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T04:33:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(330,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T04:43:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(331,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T04:53:34+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(332,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T05:03:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(333,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T05:13:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(334,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T05:23:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(335,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T05:33:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(336,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T05:43:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(337,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T05:53:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(338,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T06:03:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(339,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T06:13:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(340,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T06:24:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(341,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T06:34:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(342,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T06:44:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(343,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T06:54:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(344,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T07:04:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(345,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T07:14:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(346,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T07:24:19+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(347,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T07:34:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(348,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T07:44:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(349,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T07:54:19+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(350,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T08:04:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(351,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T08:14:29+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(352,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T08:24:31+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(353,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T08:34:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(354,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T08:44:34+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(355,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T08:54:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(356,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T09:04:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(357,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T09:14:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(358,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T09:24:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(359,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T09:34:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(360,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T09:45:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(361,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T09:55:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(362,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T10:04:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(363,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T10:15:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(364,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T10:25:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(365,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T10:35:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(366,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T10:45:06+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(367,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T10:55:16+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(368,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T11:05:18+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(369,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T11:15:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(370,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T11:25:19+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(371,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T11:35:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(372,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T11:45:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(373,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T11:55:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(374,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T12:05:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(375,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T12:15:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(376,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T12:25:37+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(377,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T12:35:29+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(378,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T12:45:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(379,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T12:55:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(380,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T13:05:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(381,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T13:15:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(382,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T13:25:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(383,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T13:35:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(384,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T13:45:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(385,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T13:56:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(386,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T14:05:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(387,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T14:16:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(388,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T14:26:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(389,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git pull --quiet: Connection reset by 140.82.121.4 port 22
fatal: Could not read from remote repository. Please make sure you have the correc',NULL,NULL,NULL,'2026-11-03T14:36:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(390,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T14:46:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(391,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T14:56:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(392,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T15:06:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(393,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T15:16:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(394,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T15:26:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(395,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T15:36:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(396,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T15:46:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(397,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T15:56:28+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(398,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T16:06:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(399,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T16:17:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(400,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T16:26:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(401,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T16:36:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(402,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T16:46:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(403,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T16:56:47+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(404,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T17:06:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(405,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T17:16:40+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(406,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T17:26:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(407,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T17:37:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(408,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T17:46:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(409,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T17:56:53+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(410,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T18:07:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(411,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T18:16:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(412,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T18:27:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(413,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T18:36:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(414,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T18:47:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(415,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T18:57:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(416,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T19:07:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(417,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T19:17:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(418,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T19:57:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(419,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T20:07:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(420,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T20:17:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(421,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T20:27:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(422,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T20:37:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(423,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T20:47:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(424,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T20:57:17+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(425,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T21:07:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(426,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T21:17:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(427,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T21:27:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(428,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T21:37:29+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(429,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T21:47:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(430,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T21:57:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(431,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T22:07:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(432,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T22:17:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(433,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T22:27:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(434,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T22:37:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(435,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T22:47:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(436,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T22:57:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(437,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T23:08:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(438,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T23:17:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(439,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T23:27:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(440,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T23:38:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(441,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T23:47:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(442,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-03T23:58:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(443,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T00:08:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(444,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T00:18:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(445,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T00:28:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(446,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T00:38:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(447,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T00:48:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(448,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T00:58:28+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(449,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T01:08:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(450,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T01:18:17+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(451,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T01:28:17+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(452,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T01:38:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(453,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T01:48:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(454,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T01:58:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(455,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T02:08:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(456,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T02:18:28+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(457,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T02:28:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(458,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T02:38:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(459,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T02:48:28+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(460,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T02:58:33+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(461,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T03:08:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(462,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T03:19:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(463,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T03:28:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(464,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T03:38:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(465,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T03:48:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(466,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T03:58:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(467,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T04:08:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(468,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T04:18:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(469,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T04:28:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(470,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T04:39:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(471,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T04:49:06+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(472,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T04:59:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(473,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T05:09:08+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(474,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T05:19:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(475,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T05:29:15+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(476,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T05:39:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(477,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T05:49:18+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(478,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T05:59:22+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(479,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T06:09:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(480,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T06:19:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(481,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T06:29:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(482,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T06:39:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(483,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T06:49:39+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(484,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T06:59:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(485,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T07:09:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(486,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T07:19:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(487,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T07:29:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(488,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T07:39:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(489,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T07:49:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(490,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T08:00:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(491,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T08:10:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(492,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T08:20:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(493,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T08:30:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(494,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T08:40:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(495,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T08:50:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(496,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T09:00:17+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(497,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T09:10:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(498,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T09:20:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(499,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T09:30:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(500,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T09:40:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(501,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T09:50:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(502,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T10:00:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(503,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T10:10:34+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(504,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T10:20:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(505,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T10:30:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(506,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T10:40:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(507,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T10:51:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(508,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T11:00:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(509,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T11:10:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(510,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T11:20:47+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(511,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T11:30:47+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(512,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T11:40:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(513,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T11:50:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(514,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T12:00:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(515,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T12:10:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(516,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T12:20:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(517,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T12:31:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(518,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git fetch --quiet: git@github.com: Permission denied (publickey).
fatal: Could not read from remote repository. Please make sure you have the',NULL,NULL,NULL,'2026-11-04T12:40:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(519,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git pull --quiet: git@github.com: Permission denied (publickey).
fatal: Could not read from remote repository. Please make sure you have the ',NULL,NULL,NULL,'2026-11-04T12:51:08+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(520,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git fetch --quiet: git@github.com: Permission denied (publickey).
fatal: Could not read from remote repository. Please make sure you have the',NULL,NULL,NULL,'2026-11-04T13:00:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(521,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git pull --quiet: git@github.com: Permission denied (publickey).
fatal: Could not read from remote repository. Please make sure you have the ',NULL,NULL,NULL,'2026-11-04T13:11:50+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(522,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T13:21:47+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(523,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git fetch --quiet: git@github.com: Permission denied (publickey).
fatal: Could not read from remote repository. Please make sure you have the',NULL,NULL,NULL,'2026-11-04T13:30:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(524,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git fetch --quiet: git@github.com: Permission denied (publickey).
fatal: Could not read from remote repository. Please make sure you have the',NULL,NULL,NULL,'2026-11-04T13:40:56+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(525,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git fetch --quiet: git@github.com: Permission denied (publickey).
fatal: Could not read from remote repository. Please make sure you have the',NULL,NULL,NULL,'2026-11-04T13:50:58+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(526,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T14:02:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(527,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git fetch --quiet: git@github.com: Permission denied (publickey).
fatal: Could not read from remote repository. Please make sure you have the',NULL,NULL,NULL,'2026-11-04T14:11:03+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(528,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git fetch --quiet: git@github.com: Permission denied (publickey).
fatal: Could not read from remote repository. Please make sure you have the',NULL,NULL,NULL,'2026-11-04T14:20:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(529,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T14:31:26+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(530,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T14:41:20+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(531,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T14:52:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(532,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T15:01:31+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(533,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T15:11:34+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(534,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T15:21:47+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(535,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T15:31:40+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(536,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T15:41:38+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(537,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T15:51:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(538,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T16:01:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(539,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T16:12:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(540,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T16:21:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(541,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T16:31:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(542,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T16:42:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(543,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T16:51:57+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(544,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T17:02:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(545,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T17:12:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(546,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T17:22:04+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(547,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T17:32:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(548,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T17:42:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(549,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T17:52:18+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(550,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T18:02:19+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(551,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T18:12:19+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(552,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T18:22:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(553,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T18:32:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(554,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T18:42:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(555,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T18:52:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(556,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T19:02:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(557,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T19:12:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(558,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T19:22:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(559,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T19:32:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(560,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T19:42:50+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(561,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T19:53:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(562,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T20:03:07+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(563,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T20:13:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(564,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T20:23:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(565,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T20:33:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(566,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T20:43:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(567,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T20:53:22+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(568,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T21:03:34+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(569,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T21:13:09+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(570,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T21:23:18+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(571,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T21:33:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(572,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T21:43:18+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(573,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T21:53:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(574,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T22:03:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(575,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T22:13:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(576,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T22:23:27+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(577,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T22:33:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(578,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T22:43:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(579,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T22:53:31+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(580,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T23:03:40+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(581,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T23:13:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(582,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T23:23:41+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(583,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T23:33:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(584,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T23:43:48+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(585,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-04T23:53:52+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(586,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T00:03:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(587,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T00:14:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(588,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T00:24:02+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(589,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T00:34:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(590,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T00:44:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(591,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T00:54:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(592,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T01:04:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(593,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T01:14:13+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(594,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T01:24:16+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(595,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T01:34:22+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(596,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T01:44:19+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(597,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T01:54:24+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(598,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T02:04:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(599,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T02:14:29+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(600,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T02:24:33+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(601,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T02:34:36+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(602,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T02:44:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(603,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T02:54:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(604,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T03:04:50+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(605,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T03:14:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(606,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T03:24:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(607,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T03:34:50+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(608,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T03:44:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(609,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T03:54:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(610,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T04:05:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(611,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T04:15:01+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(612,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T04:25:12+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(613,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T04:35:06+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(614,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T04:45:08+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(615,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T04:55:11+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(616,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T05:05:16+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(617,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T05:15:18+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(618,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T05:25:21+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(619,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T05:35:25+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(620,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T05:45:30+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(621,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T05:55:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(622,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T06:05:35+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(623,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T06:15:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(624,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T06:25:44+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(625,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T06:35:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(626,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T06:45:42+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(627,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T06:55:46+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(628,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T07:05:49+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(629,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T07:15:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(630,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T07:25:54+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(631,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T07:35:55+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(632,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T07:45:59+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(633,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T07:56:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(634,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T08:06:05+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(635,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T08:16:08+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(636,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T08:26:10+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(637,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T08:36:16+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(638,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T08:46:14+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(639,'BILGI','Bugün bir şey istenmiyor.
Görev akışı durdu: git push --quiet: ERROR: The key you are authenticating with has been marked as read only.
fatal: Could not read from remote repository. Plea',NULL,NULL,NULL,'2026-11-05T08:56:18+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(640,'BILGI','Bugün bir şey istenmiyor.
Görev tamam: Bu görev daha önce yapılmıştı; sonuç dosyası tamam ve olduğu gibi bırakıldı.',NULL,NULL,NULL,'2026-11-05T09:46:23+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(641,'BILGI','Senden istenen: Başsız oturumda komut çalıştırma izni verilmesi ya da görevin izinli bir oturumda yeniden kuyruğa konması.
Görev yarım kaldı: Görev yapılamadı çünkü bu oturumda komut çalıştırma izni yoktu; kilit yolu değişmedi, bir şey bozulmadı.',NULL,NULL,NULL,'2026-11-05T09:56:32+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(642,'BILGI','Senden istenen: Windows tarafındaki doğru ssh adı için bu depoya eklenmeli ya da ad görev mesajında verilmeli. Ad verilirse ''deki iki satır o adla değiştirilir.
Görev yarım kaldı: Sunucuya bağlanma adını yazdığı söylenen devir belgesi bu makinede yok, bu yüzden belgedeki eski satırları düzeltemedim; doğru adı bana bildi',NULL,NULL,NULL,'2026-11-05T10:06:43+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(643,'BILGI','Senden istenen: izin listesine eklenmeli. Eklenirse push''u ben yaparım, ya da karar verici elle yapar.
Görev yarım kaldı: Sunucu takma adı kılavuzda düzeltildi ve kayıt altına alındı, ama değişiklik henüz uzak depoya gönderilemedi; gönderme komutuna izin verilmes',NULL,NULL,NULL,'2026-11-05T11:17:00+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(644,'BILGI','Senden istenen: Karar vericinin bu oturumda dosya yazma iznini açması ya da dosyanın başka bir yoldan yazılması.
Görev yarım kaldı: Yeni izin dosyası bu oturumda diske yazılamadı, çünkü yazma izni reddedildi. Değişiklik yapılmadı.',NULL,NULL,NULL,'2026-11-05T11:26:51+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(645,'BILGI','Senden istenen: Rebase ve push komutlarına izin verilmesi gerekiyor. İzin verilirse görev baştan koşturulabilir. Hiçbir şey değişmediği için tekrar koşturmak güvenli.
Görev yarım kaldı: Dağıtım yapılamadı. Komut çalıştırma izni reddedildi, depoda hiçbir şey değişmedi. İzin verilirse görev yeniden koşturulabilir.',NULL,NULL,NULL,'2026-11-05T11:36:45+03:00','gitti',NULL);
INSERT INTO "tg_kuyruk" VALUES(646,'BILGI','Bugün bir şey istenmiyor.
Görev tamam: Sunucu en son sürüme getirildi ve ilgili testler sorunsuz geçti.',NULL,NULL,NULL,'2026-11-05T20:48:27+03:00','bekliyor',NULL);
