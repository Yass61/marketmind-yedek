INSERT INTO "tg_karar" VALUES(1,'OZ01-2','ONAY 2 · video + kapak','OZ01 · video + kapak','2026-10-19T14:02:00+03:00',127,0,'kapandi','2026-10-16T21:24:07+03:00','2026-10-17T14:54:28+03:00');
INSERT INTO "tg_karar" VALUES(2,'B09-1','ONAY 1 · senaryo','B09 · senaryo','2026-10-23T10:00:00+03:00',NULL,0,'kapandi','2026-10-21T10:08:35+03:00','2026-10-21T11:38:41+03:00');
INSERT INTO "tg_karar" VALUES(3,'B09-1','ONAY 1 · senaryo','B09 · senaryo','2026-10-23T10:00:00+03:00',146,1,'acik','2026-10-21T16:09:42+03:00',NULL);
