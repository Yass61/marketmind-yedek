INSERT INTO "tg_karar" VALUES(1,'OZ01-2','ONAY 2 · video + kapak','OZ01 · video + kapak','2026-10-19T14:02:00+03:00',NULL,0,'acik','2026-10-16T21:24:07+03:00',NULL);
