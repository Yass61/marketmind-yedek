INSERT INTO "tg_durum" VALUES('bekleyenler_mesaj_id','169');
INSERT INTO "tg_durum" VALUES('bekleyenler_metin','📌 <b>BEKLEYENLER</b>
Bekleyen yok');
INSERT INTO "tg_durum" VALUES('son_pencere','2026-10-29T20:30:00+03:00');
