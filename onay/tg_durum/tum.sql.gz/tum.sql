INSERT INTO "tg_durum" VALUES('bekleyenler_mesaj_id','112');
INSERT INTO "tg_durum" VALUES('bekleyenler_metin','📌 <b>BEKLEYENLER</b>
🔴 Senden bekleyen: 1
  · OZ01-2 — ONAY 2 · video + kapak · 19.10 14:02
🟡 İtiraz süresinde: 0');
INSERT INTO "tg_durum" VALUES('son_pencere','2026-10-16T20:30:00+03:00');
