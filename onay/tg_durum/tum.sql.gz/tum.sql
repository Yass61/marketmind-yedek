INSERT INTO "tg_durum" VALUES('bekleyenler_mesaj_id','148');
INSERT INTO "tg_durum" VALUES('bekleyenler_metin','📌 <b>BEKLEYENLER</b>
🔴 Senden bekleyen: 1
  · B09-1 — ONAY 1 · senaryo · 23.10 10:00
🟡 İtiraz süresinde: 0');
INSERT INTO "tg_durum" VALUES('son_pencere','2026-10-21T20:30:00+03:00');
