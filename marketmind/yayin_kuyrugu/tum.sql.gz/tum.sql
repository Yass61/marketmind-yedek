INSERT INTO "yayin_kuyrugu" VALUES(1,'C10','/home/marketmind/marketmind/output/icerik/C10_FINAL.md','Gördüğün hareketin üçte biri senin değil — ölçtük

Tavan bir güç işareti değil, yakalanamama işareti.

Tam ölçüm ve yöntem YouTube''da: Borsa Laboratuvarı

Yatırım tavsiyesi değildir','["youtube", "tiktok", "instagram", "x"]','["https://pub-651f23c9c0cb476f9ba218feed48cf8b.r2.dev/C10_dikey_dfa2575c125aa51d.mp4"]','IPTAL','{"gecti": true, "bloklar": [], "uyarilar": ["referans: referans kontrolü: sahne verisi yok, koşulmadı", "görsel denetçi sonucu YOK — yayından hemen önce bir kez koşulmalı (docs/GEMINI_KULLANIM.md)"], "kosulmayan": []}',NULL,'{}','HTTP 422: {"error":"Threads are only supported on X and Threads, not youtube, tiktok, instagram"}','2026-08-21T16:02:50','2026-09-04T11:06:56',NULL,'["https://youtube.com/@marketmind_tr"]',NULL,NULL);
INSERT INTO "yayin_kuyrugu" VALUES(2,'C10','/home/marketmind/marketmind/output/icerik/C10_FINAL.md','Gördüğün hareketin üçte biri senin değil — ölçtük

Tavan bir güç işareti değil, yakalanamama işareti.

Tam ölçüm ve yöntem YouTube''da: Borsa Laboratuvarı

Yatırım tavsiyesi değildir','["youtube", "tiktok", "instagram", "x"]','[]','IPTAL','{"gecti": true, "bloklar": [], "uyarilar": ["referans: referans kontrolü: sahne verisi yok, koşulmadı", "görsel denetçi sonucu YOK — yayından hemen önce bir kez koşulmalı (docs/GEMINI_KULLANIM.md)"], "kosulmayan": []}',NULL,NULL,NULL,'2026-08-21T22:23:44','2026-09-04T11:06:56',NULL,NULL,NULL,NULL);
INSERT INTO "yayin_kuyrugu" VALUES(3,'C10X','output/icerik/C10_FINAL.md','Gördüğün hareketin üçte biri senin değil — ölçtük

Tavan bir güç işareti değil, yakalanamama işareti.

Tam ölçüm ve yöntem YouTube''da: Borsa Laboratuvarı

Yatırım tavsiyesi değildir','["x"]','["https://pub-651f23c9c0cb476f9ba218feed48cf8b.r2.dev/C10_dikey_dfa2575c125aa51d.mp4"]','SILINDI','{"gecti": true, "bloklar": [], "uyarilar": ["referans: referans kontrolü: sahne verisi yok, koşulmadı", "görsel denetçi sonucu YOK — yayından hemen önce bir kez koşulmalı (docs/GEMINI_KULLANIM.md)"], "kosulmayan": []}','WLtGWx0','{"twitter": {"durum": "failed", "permalink": null, "hata": "Twitter API Error: Forbidden: This user is not allowed to post a video longer than 2 minutes."}, "thread_twitter": {"durum": "pending", "permalink": null, "hata": null}}',NULL,'2026-08-21T22:46:53','2026-08-22T05:35:48','2026-08-21T22:47:19','["https://youtube.com/@marketmind_tr"]',NULL,NULL);
INSERT INTO "yayin_kuyrugu" VALUES(4,'C10A','output/icerik/C10_FINAL.md','Gördüğün hareketin üçte biri senin değil — ölçtük

Tavan bir güç işareti değil, yakalanamama işareti.

Tam ölçüm ve yöntem YouTube''da: Borsa Laboratuvarı

Yatırım tavsiyesi değildir','["youtube", "tiktok", "instagram"]','["https://pub-651f23c9c0cb476f9ba218feed48cf8b.r2.dev/C10_dikey_dfa2575c125aa51d.mp4"]','GONDERILDI','{"gecti": true, "bloklar": [], "uyarilar": ["referans: referans kontrolü: sahne verisi yok, koşulmadı", "görsel denetçi sonucu YOK — yayından hemen önce bir kez koşulmalı (docs/GEMINI_KULLANIM.md)"], "kosulmayan": []}','zvtVl4P','{"youtube": {"durum": "failed", "permalink": null, "hata": "Unauthorized"}, "instagram": {"durum": "published", "permalink": "https://www.instagram.com/p/DcUH9h6iYr6", "hata": null}, "tiktok": {"durum": "published", "permalink": "https://www.tiktok.com/@marketmind_tr/video/7676574275343502593", "hata": null}, "_GOREVLER40_NOT": "Postproxy kaydi (zvtVl4P) SILINDI ama Instagram ve TikTok gonderileri HALA YAYINDA. Postproxy delete_on_platform bu iki platformda DESTEKLENMIYOR (belge + olcum). ELLE silinmeli. Kayit bu yuzden GONDERILDI kaliyor - SILINDI demek YANLIS olurdu."}',NULL,'2026-08-21T22:46:53','2026-08-22 02:35:48','2026-08-21T22:47:50','[]',NULL,NULL);
INSERT INTO "yayin_kuyrugu" VALUES(5,'C10X2','output/icerik/C10_FINAL.md','Gördüğün hareketin üçte biri senin değil — ölçtük

Tavan bir güç işareti değil, yakalanamama işareti.

Tam ölçüm ve yöntem YouTube''da: Borsa Laboratuvarı

Yatırım tavsiyesi değildir','["x"]','[]','SILINDI','{"gecti": true, "bloklar": [], "uyarilar": ["referans: referans kontrolü: sahne verisi yok, koşulmadı", "görsel denetçi sonucu YOK — yayından hemen önce bir kez koşulmalı (docs/GEMINI_KULLANIM.md)"], "kosulmayan": []}','dztoGwk','{"twitter": {"durum": "published", "permalink": "https://x.com/marketmindai_tr/status/2090889941773340745", "hata": null}, "thread_twitter": {"durum": "published", "permalink": "https://x.com/marketmindai_tr/status/2090889943627317646", "hata": null}}',NULL,'2026-08-21T22:51:51','2026-08-22T05:35:48','2026-08-21T22:52:05','["https://youtube.com/@marketmind_tr"]',NULL,NULL);
INSERT INTO "yayin_kuyrugu" VALUES(6,'C10B','/home/marketmind/marketmind/output/icerik/C10_FINAL.md','Gördüğün hareketin bir kısmı senin değil — ölçtük

Tavan güç işareti olabilir — ama senin için yakalanamama işaretidir.

Tam ölçüm ve yöntem YouTube''da: Borsa Laboratuvarı

Yatırım tavsiyesi değildir','["youtube", "tiktok", "instagram"]','["https://pub-651f23c9c0cb476f9ba218feed48cf8b.r2.dev/C10_dikey_34e5e496faef0286.mp4"]','GONDERILDI','{"gecti": true, "bloklar": [], "uyarilar": ["referans: referans kontrolü: sahne verisi yok, koşulmadı", "görsel [gorsel_degisim]: 00:00 - 00:12 arasında ekrandaki ilk slayt 12 saniye boyunca hiç değişmeden sabit duruyor."], "kosulmayan": [], "asama": "yayin", "gorsel": true}','bWt1Y06','{"youtube": "pending", "tiktok": "pending", "instagram": "pending"}',NULL,'2026-08-23T07:14:26','2026-08-23T07:19:31','2026-08-23T07:19:31',NULL,NULL,NULL);
INSERT INTO "yayin_kuyrugu" VALUES(7,'C10BX','/home/marketmind/marketmind/output/icerik/C10_FINAL.md','Gördüğün hareketin bir kısmı senin değil — ölçtük

Tavan güç işareti olabilir — ama senin için yakalanamama işaretidir.

Tam ölçüm ve yöntem YouTube''da: Borsa Laboratuvarı

Yatırım tavsiyesi değildir','["x"]','[]','GONDERILDI','{"gecti": true, "bloklar": [], "uyarilar": ["referans: referans kontrolü: sahne verisi yok, koşulmadı", "görsel [gorsel_degisim]: 00:00 - 00:12 arasında ekrandaki ilk slayt 12 saniye boyunca hiç değişmeden sabit duruyor."], "kosulmayan": [], "asama": "yayin", "gorsel": true}','jdtb6wO','{"twitter": "pending"}',NULL,'2026-08-23T07:14:26','2026-08-23T07:19:44','2026-08-23T07:19:44','["https://youtube.com/@marketmind_tr"]',NULL,NULL);
INSERT INTO "yayin_kuyrugu" VALUES(8,'V02','output/icerik/V02_FINAL.md','Beş sinyali ölçtük: BOS, CHoCH, FVG, Order Block, Sweep.
560 hisse · 10 yıl · 1 milyondan fazla deneme.

En iyi çıkanı bile anlamlı saydığımız en küçük farkın altında
kaldı. Aynı günün içine bakınca o fark da eridi.

Sinyal sana piyasayı söylemiyor — ne zaman baktığını söylüyor.

Yatırım tavsiyesi değildir.','["youtube", "instagram", "tiktok"]','["https://pub-651f23c9c0cb476f9ba218feed48cf8b.r2.dev/V02_uzun_26284dd211d110b6.mp4"]','GONDERILDI','{"gecti": true, "bloklar": [], "uyarilar": ["referans: referans kontrolü: sahne verisi yok, koşulmadı", "görsel [gorsel_degisim]: Slaytların ekranda kalma süreleri çok uzun; 00:00-00:21 (21 sn), 00:21-00:58 (37 sn), 01:53-02:31 (38 sn) ve 02:31-02:56 (25 sn) gibi aralıklarda 10 saniyeden uzun süre hiçbir görsel değişim olmuyor.", "görsel [gorsel_degisim]: Görsel değişim sıklığı düşüktür ve bazı kareler 10 saniyelik sınırı aşmaktadır (örneğin 00:00-00:20 arası 20 saniye, 00:21-00:58 arası 37 saniye boyunca aynı kart ekranda kalmaktadır)."], "kosulmayan": [], "asama": "yayin", "gorsel": true, "parmak_izi": "7c6f5b50d4fc15de"}','LKtx5pq','{"youtube": "pending", "instagram": "pending", "tiktok": "pending"}',NULL,'2026-08-24T14:23:18','2026-08-24T14:37:54','2026-08-24T14:37:54',NULL,'Beş sinyali ölçtük. Fark, sinyalden değil takvimden geliyor.','https://pub-651f23c9c0cb476f9ba218feed48cf8b.r2.dev/kapak_A_sayi_donusu_92d109139bd21bb7.png');
INSERT INTO "yayin_kuyrugu" VALUES(9,'V02X','output/icerik/V02_FINAL.md','Adil değer boşluğu, beş SMC sinyalinin en güçlüsü çıktı:
+2,4 puan.

Gürültü tabanımız 3 puan. Ve aynı güne bakınca −0,2''ye düştü.

Sinyal sana piyasayı söylemiyor — ne zaman baktığını söylüyor.','["x"]','[]','GONDERILDI','{"gecti": true, "bloklar": [], "uyarilar": ["referans: referans kontrolü: sahne verisi yok, koşulmadı", "görsel [gorsel_degisim]: Slaytların ekranda kalma süreleri çok uzun; 00:00-00:21 (21 sn), 00:21-00:58 (37 sn), 01:53-02:31 (38 sn) ve 02:31-02:56 (25 sn) gibi aralıklarda 10 saniyeden uzun süre hiçbir görsel değişim olmuyor.", "görsel [gorsel_degisim]: Görsel değişim sıklığı düşüktür ve bazı kareler 10 saniyelik sınırı aşmaktadır (örneğin 00:00-00:20 arası 20 saniye, 00:21-00:58 arası 37 saniye boyunca aynı kart ekranda kalmaktadır)."], "kosulmayan": [], "asama": "yayin", "gorsel": true, "parmak_izi": "7c6f5b50d4fc15de"}','dztoZax','{"twitter": "pending"}',NULL,'2026-08-24T14:23:18','2026-08-24T14:43:56','2026-08-24T14:43:56','["https://youtube.com/@marketmind_tr"]',NULL,NULL);
INSERT INTO "yayin_kuyrugu" VALUES(10,'V03','output/icerik/V03_FINAL.md','Omuz baş omuz, boğa bayrağı, yükselen üçgen, fincan kulp.
Teknik analizin ilk dersinde öğretilen şekiller.

Borsa İstanbul verisinde tek tek ölçtük: 252.395 formasyon günü.
Her biri için aynı soru — altmış gün içinde reel fiyat yükseldi mi?
Sonra her formasyon gününü, AYNI GÜN formasyon çıkmayan hisselerle
eşleştirdik.

Aradaki fark 0,18 puan. Karar eşiğimiz 3 puan.
Dört formasyon türünü ayrı ayrı test ettik; hiçbiri şansı geçemedi.

⚠️ Ölçtüğümüz şey BİZİM tanımımız — dönüş noktalarına yazılmış
kurallar. Bir usta grafiğe bakınca başka bir şey görüyor olabilir.
Sonuç bu sınırın içinde geçerli.

Bu içerik yatırım tavsiyesi değildir; veri analizi ve eğitim
amaçlıdır.','["youtube", "instagram", "tiktok"]','["https://pub-651f23c9c0cb476f9ba218feed48cf8b.r2.dev/V03_uzun_ec61ce4fb4638783.mp4"]','HATA','{"gecti": true, "bloklar": [], "uyarilar": ["referans: referans kontrolü: sahne verisi yok, koşulmadı", "sonunda YouTube yönlendirmesi yok — izleyici nereye gideceğini bilmiyor", "görsel [gorsel_degisim]: 01:15-01:38 (23 saniye) ve 02:14-02:34 (20 saniye) arasında ekranda hiçbir görsel değişim olmadan aynı kare uzun süre sabit kalıyor.", "saf dinleyici: 4 kısmi takılma — «yerel tepe ve dipler; yani etrafındaki barlardan yüksek tepeler, düşük dipler» kac bar etrafina bakildigi soylenmedi — 3 bar mi 20 bar mi, tanim buna bagliyken bosta kaldi.; «enflasyondan arındırılmış fiyat yükseldi mi?» ayni gun karsilastiriliyorsa enflasyon iki tarafta da ayni olacagi icin duzeltmenin ne ise yaradigi anlasilmadi.", "not: 3/7 sahne görselsiz ama YAPISAL (S1, S6, S7 — kanca/sınır/kapanış). ⭐ Ham oran %43 ama VERİ oranı %0 eşik içinde — düzeltme gerekmeyebilir."], "kosulmayan": [], "asama": "yayin", "gorsel": true, "parmak_izi": "9f90574d4e9039e8"}',NULL,'{}','HTTP 403: {"error":"Post limit reached for your plan. Please upgrade to publish more posts.","limit":10,"current_usage":10}','2026-09-04T17:40:31','2026-09-09T22:41:51',NULL,NULL,'Omuz baş omuz, bayrak, üçgen: 252.395 vakada ölçtük — fark, şanstan ayırt edilemedi','https://pub-651f23c9c0cb476f9ba218feed48cf8b.r2.dev/kapak_V03_56ab76ecae0a31d9.png');
