INSERT INTO "ai_yorumlar" VALUES(1,'ASELS','2026-05-14','baslangic','# **ASELS — Piyasa Özeti**

Aselsan hissesi şu anda yükseliş trendi içinde olup, fiyatlar genel olarak artış göstermektedir. Ancak bu yükseliş hali, trendde belirli bir durgunluk dönemine girmiş görünmektedir. Hisse, destek ve direnç seviyeleri arasında dar bir hareket alanında işlem görmektedir.

---

## **Dikkat Edilecek Seviyeler**

**Direnç Seviyeleri** (Fiyatın çıkışının engellenebildiği alanlar)
- ₺222.52 — Yakın direnç
- ₺187.36 — Daha uzaktan direnç

**Destek Seviyeleri** (Fiyatın düşüşte durabildiği alanlar)
- ₺315.38 — Güçlü destek
- ₺126.74 — Daha aşağıda yer alan destek

---

## **Olumlu Sinyaller**

- **Yükseliş trendi devam ediyor:** Fiyat genel olarak yukarı yönlü hareket göstermektedir.
- **Para akışı uyumlu:** Yatırımcıların satın alma ve satış hareketleri fiyat hareketleriyle tutarlı görünmektedir; bu, hareketin sağlıklı olduğunu gösterir.
- **Bayrak formasyonu belirlendi:** Bu şekil, yükseliş trendinin devam etme olasılığını artırmaktadır.

---

## **Dikkat Gerektiren Noktalar**

- **MACD göstergesi düşüş baskısı gösteriyor:** Bu, yükseliş momentumunun zayıfladığını işaret etmektedir; karşı harekete ilişkin bir uyarıdır.
- **RSI ortanın biraz üzerinde:** 62.8 değeri, fiyatın ne aşırı yüksek ne de çok düşük olduğunu gösterir; ancak yukarı yönde hareket etme gücü kısıtlı kalabilir.
- **Dar işlem alanı:** Hisse şu anda sıkı bir aralıkta oynaşmaktadır; bu da yönü netleşene kadar belirsizliğin devam edebileceği anlamına gelir.

---

## **Sonuç**

Aselsan, yükseliş eğilimini korumakla birlikte, momentum zayıflamakta ve duraksamaya benzemeyen bir dönem yaşamaktadır. Yakın dönemde direnç seviyelerine yaklaştığında veya destek seviyelerini test ettiğinde fiyat hareketinin daha net şekilde ortaya çıkması olasılığı artmaktadır.

---

⚠️ **Uyarı:** Bu analiz sadece eğitim ve bilgilendirme amaçlıdır. Hiçbir şekilde yatırım tavsiyesi değildir. Yatırım kararlarını almadan önce kendi araştırmanızı yapınız ve bir finansal danışmanla görüşünüz.',1619,0.004121,'2026-05-14 11:05:22');
INSERT INTO "ai_yorumlar" VALUES(2,'BTCUSDT','2026-05-14','sosyal_medya','🔔 BTCUSDT — Bayrak Formasyon & Sıkışma Bölgesinde

Teknik göstergeler ılımlı yükseliş senaryosunu destekliyor. Bayrak paterni kırılma öncesi sıkışmada konumlanmış. RSI (69.1) yüksek momentum gösteriyor ancak aşırı alım bölgesine yaklaşıyor. Destek/direnç seviyeleri net konumlandı.

📌 Destek: ₺65,031.91
🎯 Direnç: ₺94,681.82

MarketMind AI: 68/100

⚠️ Eğitim amaçlı — Yatırım tavsiyesi değildir.

---ETIKETLER---
#BTCUSDT #BIST #MarketMindAI #BorsaAnaliz #KriptoTrend',812,0.001446,'2026-05-14 11:05:26');
INSERT INTO "ai_yorumlar" VALUES(3,'TTRAK','2026-05-14','ileri','# **TTRAK — Teknik Analiz**
*MarketMind AI Skoru: 81/100*

---

## **Yapısal Okuma**

TTRAK, **yükseliş trendi içerisinde Higher High (HH) + Higher Low (HL) formasyonu** oluşturmaktadır. Bu sıralanış, makro düzeyde talep üstünlüğünün devam ettiğini göstermektedir. 

Önemli noktalar:
- **Kırılma Noktası (BOS) tespit edilmemişdir** — bu, yapının henüz güçlü bir negatif etkinlik yaşamaması anlamına gelir
- **Change of Character (CHOCH) bulunmamaktadır** — trend mekanizması sağlam görünmektedir
- Fiyatın **EMA200 altında kalması** (200 günlük ortalama), makro açıdan yapının zayıflamaya başladığını veya konsolidasyon aşamasında olduğunu işaret etmektedir

**Değerlendirme:** Lokal trend pozitif (HH+HL), ancak uzun vadeli trendde belirsizlik vardır.

---

## **Momentum & Göstergeler**

| Gösterge | Değer | Analiz |
|----------|-------|--------|
| **RSI(14)** | 43.24 | Nötr bölgede (30-70 arası). Aşırı alım/satım göstermemektedir. İnişe yönelik hafif eğilim gözlenmektedir. |
| **MACD Histogram** | +1.0846 | Pozitif ve çizgi sıfırın üstündedir — momentum yönü **bullish**. Ancak büyüklüğü orta seviyede kalması dikkat gerektirir. |
| **OBV** | Yüküş trendi | Hacim profili talep tarafında toplanmaktadır. **Uyumsuzluk yok:** fiyat ve hacim uyumlu hareket etmektedir. |
| **Uyumsuzluk (Divergence)** | Yok | Pozitif veya negatif uyumsuzluk görülmemektedir — momentum durağan değildir. |

**Değerlendirme:** Momentum kütlesi orta seviyede tutarlı. RSI nötr pozisyonu, fiyatın hızlı yükselişler yerine **dengeli ilerlediğini** göstermektedir. OBV desteği, yapılan yükselişlerin hacimle desteklendiğini teyit etmektedir.

---

## **Likidite & Önemli Seviyeler**

### **Direnç Seviyeleri (Yukarı):**
1. **₺613.25** (Güç: 4⭐) — *Birincil direnç, kuvvetli psikolojik seviye*
2. **₺581.50** (Güç: 2) — *İkincil dirençler bölgesi*
3. **₺465.25** (Güç: 1) — *Yakındaki hafif direnç*

### **Destek Seviyeleri (Aşağı):**
1. **₺551.00** (Güç: 3⭐) — *Güçlü destek bloğu*
2. **₺439.67** (Güç: 3⭐) — *Temel destek seviyesi*
3. **₺511.00** (Güç: 2) — *Orta destek*

### **Fibonacci & Golden Zone:**
- **Fibonacci bölgesi: Discount** — Fiyat, düşük değerlenmi',2036,0.004829,'2026-05-14 11:24:43');
INSERT INTO "ai_yorumlar" VALUES(5,'ASELS','2026-05-16','ileri','# **ASELS — Teknik Analiz**
*MarketMind AI Skoru: 60/100*

---

## **Yapisal Okuma**

ASELS, höyük bir yukarı trend içinde hareket etmektedir. Higher High + Higher Low (HH+HL) formasyonu, primer trend yönünün bullish kalmasını desteklemektedir. Grafik, güçlü bir **bayrak formasyonu** oluşturmuş durumdadır — bu, konsolidasyon periyodu içinde fiyatın daha sonraki hareket için enerji biriktirdiğini işaret eder.

Break of Structure (BOS) tespit edilmemiştir, bu da bulunduğu trend kanalının henüz kırılmadığını gösterir. **Kapinin kilidi zorlanıyor** durumu devam ediyor; fiyat, ₺350.00 direncini test etmeye hazırlanabilir.

---

## **Momentum & Göstergeler**

**RSI(14): 62.17** — Nötr bölgede konumlanmış. Aşırı alım (70+) veya aşırı satım (<30) teşkil etmemiş, fakat daha yukarı potansiyele açık durumda.

**MACD Histogram: -4.0264** — Negatif değer, momentum dönüşümünde potansiyel zayıflığı işaret ediyor. Hattın üzerinden aşağıya geçiş, satış basıncının arttığını göstermektedir.

**Negatif Uyumsuzluk (Bearish Divergence)**: Fiyat yükselirken momentum göstergelerinin düşüş göstermesi, yukarı trendin **motor yoruluyor** haline geldiğini ifade ediyor. Bu, önemli seviyeler civarında dikkat gerektiren bir uyarı sinyalidir.

**OBV (On-Balance Volume)**: Yukselişte — sahte kırılışlara karşı güvenilir bir gösterge. Hacim desteği devam ediyor.

**Bollinger Bands Yüzdelik (4)**: Band tabanının çok altında konumlanmış, volatilitenin aşırı genişlediğini ve retracement riskini gösterir.

---

## **Likidite & Önemli Seviyeler**

**Dirençler (yukarı taraf):**
- ₺350.00 (Güç:2) — Önemli psikolojik seviye, bayrak direnci
- ₺222.52 (Güç:2) — İkincil direnç
- ₺187.36 (Güç:2) — Teknik direnç bölgesi

**Destekler (aşağı taraf):**
- ₺315.38 (Güç:2) — Güçlü dinamik destek (yakın)
- ₺129.73 & ₺126.74 (Güç:1) — Uzun vadeli güvenlik ağı

Fiyat, ₺315.38''in altına düşerse, negatif uyumsuzluk + MACD bozulması, hızlı retracement tetikleyebilir.

---

## **MTF Analizi**

MTF verisi mevcut değildir. Günlük çerçevenin üzerindeki haftalık/aylık trendler analiz edilememiştir. **Macro kontrol şart:** Eğer haftalık trend bearish ise, günlük bullish sinyal risklidir.

---

## **Senaryo Analizi**

**📈 Bullish Senaryo:**
- Bayrak formasyonunun yukarı yönlü',1902,0.004722,'2026-05-16 18:01:57');
INSERT INTO "ai_yorumlar" VALUES(6,'ASELS','2026-05-16','baslangic','# **ASELS Özet**

**Genel Durum:**
ASELS yukarı yönlü bir trend içinde hareket ediyor, 62 RSI seviyesiyle moderate momentum gösteriyor. Hacim sıkışması, yakında volatilite artışının olabileceğini işaret ediyor.

**Olumlu Sinyaller:**
- Yükselen trend devam ediyor
- 315 TL destek seviyesi tutunabilir
- Bayrak formasyon yapısı devamını destekleyebilir

**Dikkat Noktaları:**
- RSI 62''de; 70''in üzerine çıktığında aşırı alım bölgesine girebilir
- Hacim sıkışması çözüldüğünde yön belirlenmesi önemli
- 187 TL direnci test etmek için güçlü momentum lazım

**Sonuç:**
ASELS''in 315 TL desteğini koruması, devam edecek trend için olumlu bir göstergedir.

⚠️ **Uyarı:** Kalıp kırılması, destek kayıpları ve makro ekonomik haber etkisi riski taşıyabilir. Pozisyon yönetimi yapınız.',582,0.00156,'2026-05-16 18:40:12');
INSERT INTO "ai_yorumlar" VALUES(7,'BTCUSDT','2026-05-16','sosyal_medya','**TWEET:**

BTC kararli yükselişte, RSI sıcak (69) ama hacim sıkışmış. Bayrak formasyonu bitmek üzere—94K direnç odak. 65K''de tutunacak mı? Motor yoruluyor.

MarketMind AI 68/100 ⚠️ Volatilite ani sürprizlere açık.

---
*Karakter: 268/270* ✓',363,0.00069,'2026-05-16 18:40:15');
INSERT INTO "ai_yorumlar" VALUES(8,'ASELS','2026-05-19','baslangic','**ASELS Özet**

**Genel Durum**
ASELS pozitif momentum ile yükseliş trendinde işlem görmektedir. Teknik göstergeler ılımlı güç seviyesini işaret etmektedir.

**Olumlu Sinyaller**
- Bayrak formasyonu kırılması potansiyeli taşımaktadır
- Yükseliş trendi devam etmektedir
- RSI 62 seviyesinde konumlanmış, aşırı alım bölgesine yaklaşmamıştır

**Dikkat Noktaları**
- Hacim sıkışması fiyat hareketinin zayıf olabileceğini göstermektedir
- 187 direnç seviyesi test edilmedikçe yakalayış güvenilir değildir
- Bayrak kırılması başarısız olursa 315 desteğine geri dönüş olabilir

**Sonuç**
Hacim artışıyla bayrak kırılması durumunda satın alma potansiyeli oluşabilir.

**⚠️ Uyarı Notu:** Bu analiz eğitim amaçlıdır. Pozisyon almadan önce risk yönetimi planı yapınız. Geçmiş performans gelecekteki sonuçları garantilemez.',603,0.001644,'2026-05-19 18:47:45');
INSERT INTO "ai_yorumlar" VALUES(9,'BTCUSDT','2026-05-19','sosyal_medya','**TWEET:**

BTC şu an bayrak formasyonu içinde, RSI üst bölgede. 65K destek, 94K direnci test etmeye hazır. Yükselen trendin sürükleme gücü yeterli görünüyor. Motor yoruluyor.

MarketMind AI 68/100 | ⚠️ Volatilite beklenti

---

**Karakter sayısı:** 229/270

**Uyarı:** Bu analiz eğitici amaçlıdır. İşlem kararlarınız kendi riski yönetiminize dayalı olmalıdır.',405,0.000858,'2026-05-19 18:47:48');
