INSERT INTO "endeks_gunluk" VALUES('XU100','2026-11-02',10961.67,'isyatirim/END_DEGER');
INSERT INTO "endeks_gunluk" VALUES('XU100','2026-11-03',11023.55,'isyatirim/END_DEGER');
INSERT INTO "endeks_gunluk" VALUES('XU100','2026-11-04',11478.13,'isyatirim/END_DEGER');
INSERT INTO "endeks_gunluk" VALUES('XU100','2026-11-05',11333.27,'isyatirim/END_DEGER');
INSERT INTO "endeks_gunluk" VALUES('XU100','2026-11-06',11482.6,'isyatirim/END_DEGER');
