INSERT INTO "endeks_gunluk" VALUES('XU100','2026-11-02',10961.67,'isyatirim/END_DEGER');
