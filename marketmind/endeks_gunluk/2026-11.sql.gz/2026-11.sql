INSERT INTO "endeks_gunluk" VALUES('XU100','2026-11-02',10961.67,'isyatirim/END_DEGER');
INSERT INTO "endeks_gunluk" VALUES('XU100','2026-11-03',11023.55,'isyatirim/END_DEGER');
