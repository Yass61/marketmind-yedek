INSERT INTO "endeks_gunluk" VALUES('XU100','2026-10-01',12249.04,'isyatirim/END_DEGER');
INSERT INTO "endeks_gunluk" VALUES('XU100','2026-10-02',12270.18,'isyatirim/END_DEGER');
INSERT INTO "endeks_gunluk" VALUES('XU100','2026-10-05',12443.92,'isyatirim/END_DEGER');
INSERT INTO "endeks_gunluk" VALUES('XU100','2026-10-06',12374.26,'isyatirim/END_DEGER');
INSERT INTO "endeks_gunluk" VALUES('XU100','2026-10-07',12122.94,'isyatirim/END_DEGER');
INSERT INTO "endeks_gunluk" VALUES('XU100','2026-10-08',12213.58,'isyatirim/END_DEGER');
INSERT INTO "endeks_gunluk" VALUES('XU100','2026-10-09',12265.98,'isyatirim/END_DEGER');
